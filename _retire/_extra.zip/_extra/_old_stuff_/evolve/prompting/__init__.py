"""Prompt assembly."""
