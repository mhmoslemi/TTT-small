"""
TTT-Discover - multi-problem local runner.

Config():  defaults  <  YAML  <  CLI flags
"""

import warnings
warnings.filterwarnings("ignore", category=FutureWarning)


import os
import argparse
import time
from dataclasses import dataclass, field, fields
from typing import Tuple
import numpy as np
import yaml


# ======================================================================
# Config
# ======================================================================
@dataclass
class Config:
    # Problem selector
    problem: str = "circle_packing"

        # "circle_packing", "erdos", "ac1", "ac2",
        # "denoising", "gpu_mode", "ahc",


    problem_type: str = ""        # ac1/ac2, trimul/mla_decode_nvidia, etc.

    # Model
    model_name: str = "Qwen/Qwen3-8B"
    backend: str = "auto"        # "auto" | "unsloth" | "hf"
    max_seq_length: int = 32000
    load_in_4bit: bool = False
    lora_rank: int = 32
    lora_alpha: int = 32
    lora_dropout: float = 0.0
    target_modules: Tuple[str, ...] = (
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    )


    num_circles: int = 26
    target: float = 2.635983
    sandbox_timeout_s: float = 30.0

    # RL hyperparameters
    num_steps: int = 50
    groups_per_step: int = 8
    group_size: int = 64
    num_seed_states: int = 16
    learning_rate: float = 4e-5
    kl_penalty_coef: float = 0.1
    max_new_tokens: int = 4200
    grad_clip: float = 1.0

    train_examples_per_microbatch: int = 1

    # Sampling
    temperature: float = 1.0
    top_p: float = 1.0

    # PUCT
    puct_c: float = 1.0
    max_buffer_size: int = 1000
    topk_children_per_parent: int = 2

    # Misc
    seed: int = 42
    print_responses: int = 0           # how many rollouts to print per step

    # Multi-GPU generation
    num_gpus: int = 4
    # num_gpus: int = 1
    # gpu_ids: str = "0,1,2,3,4,5,6,7"
    gpu_ids: str = "1,2,4,6"
    # gpu_ids: str = "1"


# ======================================================================
# CLI parsing + config loading (defaults < YAML < CLI)
# ======================================================================
def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="TTT-Discover multi-problem runner")
    # Problem selection
    p.add_argument("--problem", default="circle_packing",
                   help="Problem name. Loads configs/<problem>.yaml unless --config is given. "
                        "One of: circle_packing, erdos, ac1, ac2, denoising, gpu_mode.")
    p.add_argument("--config", default=None,
                   help="Explicit path to a YAML config (overrides the --problem lookup).")
    p.add_argument("--problem-type", default=None,
                   help="Sub-type for multi-mode problems (ac1/ac2, trimul/mla_decode_nvidia).")

    # CLI overrides - all default None so we can tell 'not given' from 'given'.
    p.add_argument("--backend", choices=["auto", "unsloth", "hf"], default=None)
    p.add_argument("--model-name", default=None)
    p.add_argument("--load-in-4bit", action="store_const", const=True, default=None)
    p.add_argument("--max-seq-length", type=int, default=None)
    p.add_argument("--lora-rank", type=int, default=None)
    p.add_argument("--lora-alpha", type=int, default=None)
    p.add_argument("--lora-dropout", type=float, default=None)
    p.add_argument("--num-circles", type=int, default=None)
    p.add_argument("--target", type=float, default=None)
    p.add_argument("--sandbox-timeout-s", type=float, default=None)
    p.add_argument("--num-steps", type=int, default=None,
                   help="Number of TTT-Discover steps (paper: 50)")
    p.add_argument("--groups-per-step", type=int, default=None,
                   help="Number of parent states sampled per step (paper: 8)")
    p.add_argument("--group-size", type=int, default=None,
                   help="Rollouts per parent per step (paper: 64)")
    p.add_argument("--num-seed-states", type=int, default=None)
    p.add_argument("--max-new-tokens", type=int, default=None)
    p.add_argument("--lr", type=float, default=None)
    p.add_argument("--kl-penalty-coef", type=float, default=None)
    p.add_argument("--grad-clip", type=float, default=None)
    p.add_argument("--temperature", type=float, default=None)
    p.add_argument("--top-p", type=float, default=None)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--print-responses", type=int, default=None)
    p.add_argument("--num-gpus", type=int, default=None,
                   help="Number of GPUs for parallel generation. 1 = single-process "
                        "in-line generation (no worker pool). >1 spawns that many "
                        "plain-HF generation workers, one per GPU.")
    p.add_argument("--gpu-ids", type=str, default=None,
                   help="Comma-separated physical GPU ids for the workers, e.g. "
                        "'0,1,2,3,4,5,6,7'. Defaults to 0..num_gpus-1.")
    return p


# CLI arg name -> config key (only where they differ)
_CLI_TO_CFG = {"lr": "learning_rate"}


def load_config():
    """
    Merge Config() defaults < YAML(configs/<problem>.yaml or --config) < CLI flags.

    Returns (cfg, merged) where:
      cfg    is a Config built from the engine-level fields, and
      merged is the full dict (including problem-only keys like num_circles,
             problem_type, budget_s, score_scale, gpu_type, task_yaml, lib_dir),
             which is what the problem registry consumes.
    """
    args = _build_arg_parser().parse_args()

    # 1) defaults from the dataclass
    merged = {f.name: getattr(Config(), f.name) for f in fields(Config)}

    # 2) YAML overlay
    cfg_path = args.config or os.path.join("configs", f"{args.problem}.yaml")
    ydict = {}
    if os.path.exists(cfg_path):
        with open(cfg_path) as f:
            ydict = yaml.safe_load(f) or {}
        merged.update(ydict)
        print(f"[config] loaded {cfg_path}")
    elif args.config is not None:
        raise FileNotFoundError(f"--config path not found: {cfg_path}")
    else:
        print(f"[config] no YAML at {cfg_path}; using Config() defaults + CLI")

    # The registry routing key is the YAML's `problem` field when present
    # (this lets e.g. configs/gpu_mode_trimul.yaml declare `problem: gpu_mode`
    # while --problem just selects the file). With no YAML, --problem is the key.
    merged["problem"] = ydict.get("problem", args.problem)

    # 3) CLI overlay (only explicitly-provided values)
    skip = {"problem", "config", "problem_type"}
    for arg_name, value in vars(args).items():
        if arg_name in skip or value is None:
            continue
        key = _CLI_TO_CFG.get(arg_name, arg_name)
        merged[key] = value
    if args.problem_type is not None:
        merged["problem_type"] = args.problem_type

    # 4) build the Config from the fields it knows; leave the rest in `merged`
    known = {f.name for f in fields(Config)}
    cfg_kwargs = {k: v for k, v in merged.items() if k in known}
    cfg = Config(**cfg_kwargs)
    return cfg, merged


# ======================================================================
# Generation
# ======================================================================
def _generate_batch(model, tokenizer, inputs, input_len, n_samples, cfg):
    """
    Generate n_samples completions for a SINGLE prompt in ONE batched
    model.generate() call (via num_return_sequences). Returns a list of
    (text, gen_token_ids).
    """
    import torch
    eos_id = tokenizer.eos_token_id
    pad_id = tokenizer.pad_token_id or eos_id

    with torch.inference_mode():
        out = model.generate(
            **inputs,
            max_new_tokens=cfg.max_new_tokens,
            do_sample=True,
            temperature=cfg.temperature,
            top_p=cfg.top_p,
            pad_token_id=pad_id,
            num_return_sequences=n_samples,
        )
    results = []
    for i in range(out.shape[0]):
        gen_ids = out[i, input_len:].tolist()
        if eos_id is not None and eos_id in gen_ids:
            gen_ids = gen_ids[: gen_ids.index(eos_id) + 1]
        text = tokenizer.decode(gen_ids, skip_special_tokens=True)
        results.append((text, gen_ids))
    return results


def generate_responses(model, tokenizer, prompt_text: str, group_size: int, cfg: Config):
    """
    Generate `group_size` responses from a single prompt, batched.

    Try to generate all `group_size` at once. If OOMs, halve the
    per-call batch size and retry, accumulating until we have group_size
    responses. This keeps the algorithm identical (still group_size IID
    samples from the same policy) while using the GPU in parallel.

    Returns (list of (text, gen_token_ids), prompt_len_in_tokens).
    """
    import torch
    inputs = tokenizer(prompt_text, return_tensors="pt").to(model.device)
    input_len = inputs.input_ids.shape[1]

    responses = []
    remaining = group_size
    # Start by trying the whole group in one call.
    batch = group_size

    while remaining > 0:
        n = min(batch, remaining)
        try:
            chunk = _generate_batch(model, tokenizer, inputs, input_len, n, cfg)
            responses.extend(chunk)
            remaining -= n
        except torch.cuda.OutOfMemoryError:
            torch.cuda.empty_cache()
            if batch == 1:
                # Can't even do one - re-raise, nothing we can do
                raise
            batch = max(1, batch // 2)
            print(f"  [oom] halving generation batch size to {batch}")

    return responses, input_len


# ======================================================================
# Logprob computation
# ======================================================================
def compute_token_logprobs(model, prompt_ids, response_ids, with_grad: bool):
    """
    Returns the per-token log-probabilities of the response under the model.

    prompt_ids:   (1, P) tensor
    response_ids: (1, R) tensor
    Output:       (R,) tensor of token logprobs
    """
    import torch
    import torch.nn.functional as F

    full_ids = torch.cat([prompt_ids, response_ids], dim=1)
    context = torch.enable_grad() if with_grad else torch.no_grad()
    with context:
        out = model(full_ids)
        logits = out.logits  # (1, T, V)
        P = prompt_ids.shape[1]
        R = response_ids.shape[1]
        # Predict response token at position P+k from logits at position P+k-1
        pred_logits = logits[:, P - 1 : P - 1 + R, :]
        log_probs = F.log_softmax(pred_logits.float(), dim=-1)
        gathered = log_probs.gather(2, response_ids.unsqueeze(-1)).squeeze(-1)  # (1, R)
    return gathered.squeeze(0)


# ======================================================================
# LoRA adapter sync (main process -> generation workers)
# ======================================================================
def _adapter_dir(exp_dir, step_idx):
    from pathlib import Path
    return str(Path(exp_dir) / f"adapter_step{step_idx:03d}")


def _adapter_exists(exp_dir):
    from pathlib import Path
    p = Path(exp_dir)
    return any(p.glob("adapter_step*"))


def _save_adapter(model, exp_dir, step_idx):
    """
    Save the current LoRA adapter to disk so generation workers can load it.
    Returns the directory path. Cleans up the previous step's adapter to
    avoid filling the disk (we only ever need the latest).
    """
    import shutil
    from pathlib import Path

    out_dir = _adapter_dir(exp_dir, step_idx)
    # PEFT/Unsloth models support save_pretrained, which writes just the adapter
    model.save_pretrained(out_dir)

    # Remove older adapter dirs (keep only the current one)
    for old in Path(exp_dir).glob("adapter_step*"):
        if str(old) != out_dir:
            try:
                shutil.rmtree(old)
            except Exception:
                pass

    return out_dir



# =====================================================================
# RL PART -- SVPG (Stein Variational Policy Gradient)
# =====================================================================
# THE DIVERSITY AXIS: attacks mode collapse at the GRADIENT level rather than
# via search heuristics. Maintain an ensemble of `svpg_num_particles` policies
# as separate LoRA adapters over the same frozen base. Each particle does its
# own on-policy rollouts and policy gradient; a single SVGD step then couples
# them:
#
#   phi(theta_i) = (1/n) sum_j [ k(theta_j,theta_i) grad_J(theta_j)
#                                + alpha grad_{theta_j} k(theta_j,theta_i) ]
#
#   - k: RBF over flattened LoRA params, bandwidth h via median heuristic.
#   - attractive term: kernel-smoothed reward gradient (shares signal).
#   - repulsion term: pushes particles apart; alpha = svpg_temperature.
#   We ASCEND J; the optimizer descends, so we write grad_i = -phi into each
#   particle's .grad. The RBF repulsion gradient is analytic (no 2nd-order autograd):
#     grad_{theta_j} k = k * (-2/h)(theta_j - theta_i).
#
# COST: n x the per-step generation+scoring+backward. Default n=3. The OUTER
# SEARCH IS STILL SHARED: every valid program from every particle feeds the one
# PUCT archive. State is held outside `model`: each particle is a dict of
# trainable (LoRA) param tensors with its own AdamW (so Adam moments stay
# per-particle); `model` is a scratch compute engine we load particles into.
# The `optimizer` argument passed by main() is IGNORED here.
#
# Knobs (getattr): svpg_num_particles (3), svpg_temperature (1.0),
#                  svpg_init_std (0.01), svpg_lr (0.0 => cfg.learning_rate)
# =====================================================================
def _svpg_save_adapter(model, exp_dir, step_idx, particle):
    import shutil
    from pathlib import Path
    out_dir = str(Path(exp_dir) / f"adapter_step{step_idx:03d}_p{particle}")
    model.save_pretrained(out_dir)
    keep_prefix = f"adapter_step{step_idx:03d}_"
    for old in Path(exp_dir).glob("adapter_step*"):
        if not old.name.startswith(keep_prefix):
            try:
                shutil.rmtree(old)
            except Exception:
                pass
    return out_dir


def _svpg_trainable_names(model):
    return [n for n, p in model.named_parameters() if p.requires_grad]


def _svpg_get_particles(model, cfg):
    """Lazily create n LoRA-param particles + n AdamW optimizers, stash on model."""
    import torch
    if getattr(model, "_svpg_particles", None) is not None:
        return (model._svpg_particles, model._svpg_opts, model._svpg_names)

    n = int(getattr(cfg, "svpg_num_particles", 3))
    init_std = float(getattr(cfg, "svpg_init_std", 0.01))
    lr = float(getattr(cfg, "svpg_lr", 0.0)) or cfg.learning_rate

    names = _svpg_trainable_names(model)
    name2param = dict(model.named_parameters())

    particles = []
    opts = []
    for i in range(n):
        pd = {}
        for nm in names:
            base = name2param[nm].detach().clone()
            if i > 0:
                base = base + init_std * torch.randn_like(base)
            pd[nm] = torch.nn.Parameter(base, requires_grad=True)
        particles.append(pd)
        opts.append(torch.optim.AdamW(list(pd.values()), lr=lr,
                                      betas=(0.9, 0.95), eps=1e-8, weight_decay=0.0))

    model._svpg_particles = particles
    model._svpg_opts = opts
    model._svpg_names = names
    nparam = sum(int(np.prod(tuple(name2param[nm].shape))) for nm in names)
    print(f"[init] SVPG ensemble: {n} particles x {nparam:,} LoRA params  "
          f"(alpha={float(getattr(cfg, 'svpg_temperature', 1.0))}, lr={lr})")
    return particles, opts, names


def _svpg_load_particle(model, particle, names):
    import torch
    name2param = dict(model.named_parameters())
    with torch.no_grad():
        for nm in names:
            name2param[nm].data.copy_(particle[nm].data)


def _svpg_flatten_params(particle, names):
    import torch
    return torch.cat([particle[nm].data.reshape(-1).float() for nm in names])


def _svpg_flatten_grads(model, names):
    import torch
    name2param = dict(model.named_parameters())
    flats = []
    for nm in names:
        g = name2param[nm].grad
        if g is None:
            flats.append(torch.zeros(name2param[nm].numel(), device=name2param[nm].device))
        else:
            flats.append(g.detach().reshape(-1).float())
    return torch.cat(flats)


def _svpg_unflatten_to_grad(particle, names, vec):
    offset = 0
    for nm in names:
        p = particle[nm]
        numel = p.numel()
        chunk = vec[offset: offset + numel].reshape(p.shape).to(p.dtype)
        p.grad = chunk.clone()
        offset += numel


def _svpg_descent_grads(thetas, grads, alpha):
    """thetas, grads: lists of flat tensors. grads are LOSS gradients (= -grad J).
    Returns the SVGD descent grad per particle (= -phi, the ascent direction on J)."""
    import torch
    n = len(thetas)
    Theta = torch.stack(thetas)                       # (n, D)
    G = torch.stack(grads)                            # (n, D) = grad of loss
    sq = torch.cdist(Theta, Theta) ** 2               # (n, n)
    pos = sq[sq > 0]
    med = torch.median(pos) if pos.numel() > 0 else torch.tensor(1.0, device=Theta.device)
    h = torch.clamp(med / max(np.log(max(n, 2)), 1.0), min=1e-8)
    K = torch.exp(-sq / h)                            # K[j, i]
    out = []
    for i in range(n):
        kcol = K[:, i].unsqueeze(1)                   # (n, 1)
        attractive = (kcol * G).sum(dim=0) / n        # = -(1/n) sum_j K[j,i] grad_J_j
        diff = Theta - Theta[i].unsqueeze(0)          # theta_j - theta_i
        rep_ascent = (kcol * (-2.0 / h) * diff).sum(dim=0) / n
        out.append(attractive - alpha * rep_ascent)   # descent grad = -phi
    return out, float(K.mean().item()), float(h.item())


def train_step(backend, model, tokenizer, sampler, optimizer, step_idx: int,
               cfg: Config, exp_dir, problem, gen_pool=None):
    import os
    import torch
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from sampler import State
    from experiment_io import save_rollout
    from problems.base import ParentContext
    from gen_workers import make_progress_bar

    alpha = float(getattr(cfg, "svpg_temperature", 1.0))
    step_t0 = time.time()

    particles, opts, names = _svpg_get_particles(model, cfg)
    n_particles = len(particles)

    # ----- BUILD PROMPTS (shared across particles); record_expansion here -----
    sampler.set_current_step(step_idx)
    parents = sampler.sample_states(cfg.groups_per_step)
    print(f"\n[step {step_idx}] parents picked: {len(parents)}")
    for i, info in enumerate(sampler.last_picks_info):
        tag = "seed" if info["is_seed"] else "expanded"
        print(f"  parent {i} [{tag}]  value={info['value']:.4f}  n={info['n']}  "
              f"Q={info['Q']:.4f}  P={info['P']:.4f}  bonus={info['bonus']:.4f}  "
              f"score={info['score']:.4f}")

    prompts_by_group = []
    parent_ctxs = []
    for g, parent in enumerate(parents):
        sampler.record_expansion(parent, count=cfg.group_size)
        pc = ParentContext(
            code=parent.code,
            value=parent.value if parent.value is not None else 0.0,
            raw_score=parent.raw_score,
            construction=parent.construction,
        )
        parent_ctxs.append(pc)
        messages = problem.build_prompt(pc)
        try:
            prompt_text = tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            prompt_text = tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True,
            )
        prompts_by_group.append(prompt_text)

    num_groups = len(parents)
    total_rollouts = num_groups * cfg.group_size
    n_reward_workers = getattr(cfg, "reward_workers", 0)
    if not n_reward_workers:
        n_reward_workers = max(1, (os.cpu_count() or 8) - max(0, cfg.num_gpus))

    all_children = []
    thetas, grads = [], []
    particle_meanR = []

    rollout_t0 = time.time()
    for pi in range(n_particles):
        # Load particle pi into the live model.
        _svpg_load_particle(model, particles[pi], names)

        # ----- per-particle rollouts + rewards (same streaming as TTT) -----
        reward_pool = ThreadPoolExecutor(max_workers=n_reward_workers)
        group_responses = {g: [] for g in range(num_groups)}
        reward_futures = {g: [] for g in range(num_groups)}

        def _submit_rollout(g, text, token_ids):
            group_responses[g].append((text, token_ids))
            reward_futures[g].append(reward_pool.submit(
                problem.compute_reward, text, parent_ctxs[g], cfg.sandbox_timeout_s))

        try:
            if gen_pool is not None:
                adapter_path = _svpg_save_adapter(model, exp_dir, step_idx, pi)
                for group_idx, job_results in gen_pool.iter_group_jobs(
                        prompts_by_group=prompts_by_group,
                        group_size=cfg.group_size,
                        adapter_path=adapter_path,
                        max_new_tokens=cfg.max_new_tokens,
                        temperature=cfg.temperature,
                        top_p=cfg.top_p,
                ):
                    for (text, token_ids) in job_results:
                        _submit_rollout(group_idx, text, token_ids)
            else:
                backend.set_inference_mode()
                gen_bar = make_progress_bar(total_rollouts, desc=f"p{pi} rollouts")
                try:
                    for g, prompt_text in enumerate(prompts_by_group):
                        responses, _ = generate_responses(
                            model, tokenizer, prompt_text, cfg.group_size, cfg)
                        for (text, token_ids) in responses:
                            _submit_rollout(g, text, token_ids)
                        gen_bar.update(len(responses))
                finally:
                    gen_bar.close()

            all_futs = [f for g in range(num_groups) for f in reward_futures[g]]
            eval_bar = make_progress_bar(len(all_futs), desc=f"p{pi} evaluating")
            try:
                for _ in as_completed(all_futs):
                    eval_bar.update(1)
            finally:
                eval_bar.close()
        finally:
            reward_pool.shutdown(wait=True)

        # ----- score, save rollouts, shared-archive children, collect examples -----
        examples = []
        meanR = []
        for g, parent in enumerate(parents):
            prompt_text = prompts_by_group[g]
            responses = group_responses[g]
            futs = reward_futures[g]

            rewards, codes, valids, outs = [], [], [], []
            for r_idx, (text, token_ids) in enumerate(responses):
                res = futs[r_idx].result()
                rewards.append(res.reward)
                codes.append(res.code or "")
                valids.append(res.valid)
                outs.append(res)

            rewards_np = np.array(rewards, dtype=np.float64)
            advantages = (rewards_np - rewards_np.mean()) / (rewards_np.std() + 1e-8)
            meanR.append(float(rewards_np.mean()))

            for r_idx, (text, token_ids) in enumerate(responses):
                res = outs[r_idx]
                meta = {
                    "step": step_idx, "group": g, "rollout": r_idx, "particle": pi,
                    "reward": float(rewards[r_idx]),
                    "raw_score": (float(res.raw_score) if res.raw_score is not None else None),
                    "valid": bool(valids[r_idx]), "parsed": bool(res.parsed),
                    "ran": bool(res.ran), "msg": res.msg,
                    "advantage": float(advantages[r_idx]),
                    "algo": "svpg",
                    "n_response_tokens": len(token_ids),
                    "sandbox_stdout": (res.stdout or "")[:2000],
                    "parent_value": float(parent.value) if parent.value is not None else None,
                    "parent_is_seed": parent.id in sampler._seed_ids,
                }
                # group key offset by particle so saved rollouts do not collide
                save_rollout(exp_dir, step_idx, g * 100 + pi, r_idx, text, meta)

            for r_idx, (text, token_ids) in enumerate(responses):
                res = outs[r_idx]
                if valids[r_idx] and codes[r_idx]:
                    all_children.append((State.make(
                        timestep=step_idx, value=rewards[r_idx], code=codes[r_idx],
                        raw_score=res.raw_score, construction=res.construction), parent))

            if float(rewards_np.max() - rewards_np.min()) < 1e-12:
                continue

            prompt_ids = tokenizer(prompt_text, return_tensors="pt").input_ids.to(model.device)
            for (text, token_ids), adv in zip(responses, advantages):
                if len(token_ids) == 0:
                    continue
                examples.append({
                    "prompt_ids": prompt_ids,
                    "response_ids": torch.tensor([token_ids], device=model.device),
                    "advantage": float(adv),
                })

        particle_meanR.append(float(np.mean(meanR)) if meanR else float("nan"))

        # ----- this particle's policy gradient -> model.grad -> flat vector -----
        backend.set_training_mode()
        model.zero_grad(set_to_none=True)
        avg_loss = 0.0
        if examples:
            ne = len(examples)
            for ex in examples:
                pid, rid, adv = ex["prompt_ids"], ex["response_ids"], ex["advantage"]
                cur_lp = compute_token_logprobs(model, pid, rid, with_grad=True)
                try:
                    with backend.disable_adapter(), torch.no_grad():
                        base_lp = compute_token_logprobs(model, pid, rid, with_grad=False)
                except Exception:
                    base_lp = cur_lp.detach()
                logp_diff = (cur_lp - base_lp).detach()
                kl_adv = cfg.kl_penalty_coef * (logp_diff.mean() - (cur_lp - base_lp))
                eff_adv = adv + kl_adv
                loss = -(eff_adv.detach() * cur_lp).mean()
                (loss / ne).backward()
                avg_loss += float(loss.detach().item())
            avg_loss /= ne

        thetas.append(_svpg_flatten_params(particles[pi], names))
        grads.append(_svpg_flatten_grads(model, names))
        print(f"  [particle {pi}] meanR={particle_meanR[-1]:.4f}  "
              f"examples={len(examples)}  policy_loss={avg_loss:.4f}")

    rollout_time = time.time() - rollout_t0
    print(f"[step {step_idx}] rollout+eval time (all particles): {rollout_time:.1f}s  "
          f"new children: {len(all_children)}")
    sampler.update(all_children)

    # ----- SVGD combination + per-particle optimizer step -----
    train_t0 = time.time()
    descent_grads, kmean, h = _svpg_descent_grads(thetas, grads, alpha)
    for pi in range(n_particles):
        _svpg_unflatten_to_grad(particles[pi], names, descent_grads[pi])
        torch.nn.utils.clip_grad_norm_(list(particles[pi].values()), max_norm=cfg.grad_clip)
        opts[pi].step()
        opts[pi].zero_grad(set_to_none=True)

    # Load the best particle (highest meanR this step) back into the live model.
    if all(np.isnan(particle_meanR)):
        best_p = 0
    else:
        best_p = int(np.nanargmax(particle_meanR))
    _svpg_load_particle(model, particles[best_p], names)

    print(f"[step {step_idx}] SVGD step: kernel_mean={kmean:.4f}  bandwidth_h={h:.4g}  "
          f"alpha={alpha}  best_particle={best_p}  (train {time.time() - train_t0:.1f}s)")

    best = sampler.best_state()
    if best is not None:
        raw = f" raw={best.raw_score:.6f}" if best.raw_score is not None else ""
        print(f"[step {step_idx}] best so far: value={best.value:.6f}{raw}  "
              f"(step total {time.time() - step_t0:.1f}s, archive={sampler.archive_size()})")



# ======================================================================
# Main
# ======================================================================
def main():
    cfg, merged = load_config()

    # Build the problem from the merged config (the registry reads problem-only
    # knobs like num_circles / problem_type / budget_s / score_scale from here).
    from problems.registry import get_problem
    problem = get_problem(cfg.problem, merged)

    print("=" * 70)
    print("TTT-Discover - local multi-problem implementation")
    print("=" * 70)
    print(f"Problem:            {cfg.problem}"
          + (f" ({cfg.problem_type})" if cfg.problem_type else ""))
    print(f"Entrypoint:         {getattr(problem, 'entrypoint', '?')}")
    print(f"Metric:             {getattr(problem, 'metric_name', '?')} "
          f"({'maximize' if getattr(problem, 'maximize', True) else 'minimize'})")
    print(f"Model:              {cfg.model_name}")
    print(f"Backend:            {cfg.backend}")
    print(f"Target:             {cfg.target}")
    print(f"Steps:              {cfg.num_steps}")
    print(f"Groups per step:    {cfg.groups_per_step}")
    print(f"Group size:         {cfg.group_size}")
    print(f"Total rollouts/step: {cfg.groups_per_step * cfg.group_size}")
    print(f"LR:                 {cfg.learning_rate}")
    print(f"KL coef:            {cfg.kl_penalty_coef}")
    print(f"Max new tokens:     {cfg.max_new_tokens}")
    print(f"Sandbox timeout:    {cfg.sandbox_timeout_s}s")
    print("=" * 70)

    # ---- experiment dir ----
    from experiment_io import make_experiment_dir, save_final_summary
    exp_dir = make_experiment_dir(cfg)
    print(f"[init] writing all rollouts to: {exp_dir}")

    # ---- seed states (problem-defined) ----
    seeds = problem.seed_states()
    print(f"[init] problem produced {len(seeds)} seed state(s)")

    # ---- backend + model ----
    # Load backend FIRST so Unsloth can patch transformers if used.
    from model_backend import load_backend
    backend = load_backend(cfg.backend, cfg)
    model, tokenizer = backend.load()

    import torch  # safe to import now
    torch.manual_seed(cfg.seed)
    np.random.seed(cfg.seed)

    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=cfg.learning_rate,
        betas=(0.9, 0.95),
        eps=1e-8,
        weight_decay=0.0
    )
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    print(f"[init] trainable params: {trainable:,} / total {total:,} "
          f"({100 * trainable / total:.2f}%)")

    # ---- sampler ----
    from sampler import PUCTSampler
    sampler = PUCTSampler(
        num_seeds=len(seeds) if seeds else cfg.num_seed_states,
        puct_c=cfg.puct_c,
        max_buffer_size=cfg.max_buffer_size,
        topk_children=cfg.topk_children_per_parent,
        seed_value=0.0,
        seed_states=seeds,
    )
    print(f"[init] sampler archive size = {sampler.archive_size()}")

    # ---- generation pool (multi-GPU) ----
    gen_pool = None
    if cfg.num_gpus and cfg.num_gpus > 1:
        from gen_workers import GenerationPool
        if cfg.gpu_ids:
            gpu_ids = [int(x) for x in cfg.gpu_ids.split(",")]
        else:
            gpu_ids = list(range(cfg.num_gpus))
        print(f"[init] starting generation pool: {cfg.num_gpus} GPUs {gpu_ids}")
        gen_pool = GenerationPool(
            model_name=cfg.model_name,
            num_workers=cfg.num_gpus,
            gpu_ids=gpu_ids,
            max_seq_length=cfg.max_seq_length,
            load_in_4bit=cfg.load_in_4bit,
        )
        print("[init] generation pool ready")
    else:
        print("[init] single-GPU generation (no worker pool)")


    # ---- Elo re-ranker (optional, background thread) ----
    reranker = None
    try:
        from reranker.config import RerankerConfig
        rcfg = RerankerConfig.from_dict(merged)
        if rcfg.enabled:
            from reranker.judges import make_judge
            from reranker.reranker import MultiAgentReRanker
            judge = make_judge(rcfg)
            if judge is not None:
                reranker = MultiAgentReRanker(
                    sampler=sampler,
                    judge=judge,
                    cfg=rcfg,
                    metric_name=getattr(problem, "metric_name", "score"),
                    maximize=getattr(problem, "maximize", True),
                    target=getattr(problem, "target", None),
                    exp_dir=exp_dir,
                )


                reranker.start()
                print(f"[init] Elo re-ranker started "
                      f"(backend={rcfg.backend}, model={rcfg.model}, "
                      f"top_k={rcfg.top_k}, debate={rcfg.debate})")
            else:
                print("[init] Elo re-ranker enabled but judge unavailable; "
                      "continuing with rank-based prior")
        else:
            print("[init] Elo re-ranker disabled")
    except Exception as e:
        print(f"[init] Elo re-ranker setup failed ({e!r}); "
              f"continuing with rank-based prior")
        reranker = None


    # ---- main loop ----
    try:
        for step in range(cfg.num_steps):
            train_step(backend, model, tokenizer, sampler, optimizer, step,
                       cfg, exp_dir, problem, gen_pool)
    finally:
        if reranker is not None:
            print("[shutdown] stopping Elo re-ranker ...")
            reranker.stop()
        if gen_pool is not None:
            print("[shutdown] stopping generation pool ...")
            gen_pool.shutdown()

    # ---- summary ----
    print("\n" + "=" * 70)
    print("TRAINING DONE")
    print("=" * 70)
    best = sampler.best_state()
    if best is not None:
        raw = f"  (raw {getattr(problem, 'metric_name', 'metric')} = {best.raw_score:.6f})" \
            if best.raw_score is not None else ""
        print(f"Best reward (higher=better): {best.value:.6f}{raw}")
        print(f"Found at step:     {best.timestep}")
        print(f"\n--- best code ---\n{best.code}\n--- end ---")
        save_final_summary(exp_dir, best.value, best.code, best.timestep)
    else:
        print("No valid solution was ever produced.")
        save_final_summary(exp_dir, None, None, None)
    print(f"\nAll outputs saved under: {exp_dir}")


if __name__ == "__main__":
    main()
