"""
Memory configuration (Sec. 2.2, as revised).

`enabled` is the master switch, read from the single key `memory`. When it is
False, from_dict returns the disabled default without consulting any other
memory_* key.

Two things are gone from the previous version, because the module no longer
uses embeddings at all: embed_backend / embed_model / embed_dim / embed_device,
and top_m / min_similarity / importance_weight / dedup_threshold. Retrieval is
now the model reading a catalog of the whole bank and naming what it wants, and
deduplication is lexical. Any of those keys left in a YAML will be reported as
unknown rather than silently ignored.
"""

from __future__ import annotations

from dataclasses import dataclass, fields
import math
from typing import Any, Dict

PREFIX = "memory_"
_MISSING = object()

# Keys from the embedding-based version. Named explicitly so an old YAML gets a
# pointed message instead of a generic "unknown key".
RETIRED = {
    "memory_embed_backend", "memory_embed_model", "memory_embed_dim",
    "memory_embed_device", "memory_top_m", "memory_min_similarity",
    "memory_importance_weight", "memory_dedup_threshold",
    "memory_retrieval_scope",
}


@dataclass
class MemoryConfig:
    enabled: bool = False
    # V1 is the historical implementation. V2 gates the corrected causal
    # design so old runs and ablations remain reproducible.
    version: str = "V1"

    # --- lookup (replaces Eq. 7 retrieval) ---
    # select : show the model a catalog of the bank, it names the ids it wants.
    #          One extra LLM call per step (all parents batched together).
    # all    : inject the entire bank into every prompt. No extra call, but the
    #          rollout prompt carries the whole bank.
    # none   : never inject. For measuring extraction in isolation.
    lookup_mode: str = "select"
    lookup_max_select: int = 5      # ceiling on what the model may ask for
    lookup_max_new_tokens: int = 256
    lookup_temperature: float = 0.3  # near-greedy; this is a selection, not prose
    lookup_fallback: str = "none"    # none | recent | importance

    # --- catalog shown to the selector and to the extractor ---
    catalog_max_lessons: int = 0     # 0 = the whole bank, which is the point
    catalog_chars: int = 200         # per-entry summary budget

    # --- injection ---
    inject_mode: str = "append"      # append | system
    token_budget: int = 1200         # cap on the injected block
    grant_context: bool = True       # add that budget to max_seq_length

    # --- budget-neutral causal arms ---
    # Split the EXISTING K rollouts for a parent across prompt variants. No
    # extra programs are generated or evaluated. A permanent null arm makes it
    # possible to measure whether memory helps the reward tail instead of only
    # observing that the model chose/repeated a lesson.
    arm_control_fraction: float = 0.0   # no-memory share; 0 keeps legacy behavior
    arm_explore_fraction: float = 0.0   # under-tested lesson share
    arm_max_lessons: int = 1            # causal credit is cleanest at one/arm
    arm_exploration_c: float = 0.5       # UCB uncertainty bonus
    # V2 freezes one best-of-n estimand for the entire run. Zero derives n from
    # the initial group size and arm fractions before the run is persisted.
    arm_comparison_n: int = 0
    outcome_credit: bool = False         # update lessons from matched best@K uplift
    text_reinforce: bool = True          # legacy LLM "confirmations"

    # --- extraction (Sec. 2.2) ---
    # Which side of the batch produces lessons.
    #   both     : one call over S_t and one over F_t (the paper's 2L per step)
    #   failure  : only F_t. One call per step instead of two, and the bank holds
    #              only failure modes and their preventative measures.
    #   success  : only S_t.
    # This is about EXTRACTION, not injection: whatever ends up in the bank is
    # what the lookup can choose from.
    # How the batch is shown to the maker.
    #   contrast : ONE call over successes and failures together, asked why some
    #              worked and others did not (ReasoningBank self-contrast). A
    #              contrast exists even when the successes are indistinguishable
    #              from each other, which is the plateau case.
    #   split    : the paper's separate prompt+ / prompt- calls.
    extract_mode: str = "contrast"   # contrast | split
    extract_from: str = "both"       # both | failure | success  (split mode only)
    lessons_per_call: int = 3        # L, a ceiling
    require_full_lessons: bool = False
    max_examples_per_call: int = 8
    max_chars_per_example: int = 1500
    feedback_chars: int = 800
    reinforce_delta: float = 0.15
    max_new_tokens: int = 1024
    temperature: float = 0.7
    top_p: float = 0.95
    use_gen_pool: bool = True

    # --- extraction hygiene: the Table 3 problem ---
    # A lesson may describe an OPERATION. It may not hand over a CONSTRUCTION.
    forbid_constructions: bool = True
    hygiene_profile: str = "auto"    # auto | geometry | kernel | generic
    max_code_lines: int = 4          # longer code blocks are rejected outright
    global_scope_allows_code: bool = False

    # --- curation (Dynamic Cheatsheet) ---
    # Every N steps, hand the model the whole bank and take back the bank it
    # wants to keep. Anything not carried forward is dropped, which is what
    # forces a retention decision instead of an accumulation.
    curate_every: int = 0            # 0 = never
    curate_min_bank: int = 20        # do not curate a bank smaller than this
    curate_max_items: int = 60
    curate_max_new_tokens: int = 4096
    curate_min_keep_frac: float = 0.25   # reject a rewrite that drops more than this

    # --- bank ---
    max_lessons: int = 500
    dedup_jaccard: float = 0.6       # token-set overlap that counts as the same lesson
    persist: bool = True

    @classmethod
    def from_dict(cls, d: Dict[str, Any], verbose: bool = True) -> "MemoryConfig":
        d = dict(d or {})
        enabled = bool(d.get("memory", False))

        if not enabled:
            defaults = cls()
            ignored = sorted(
                k for k, v in d.items()
                if k.startswith(PREFIX) and v is not None
                and getattr(defaults, k[len(PREFIX):], _MISSING) != v
            )
            if verbose and ignored:
                print(f"[memory] disabled (--memory not set); ignoring "
                      f"{len(ignored)} memory_* key(s): {', '.join(ignored)}")
            cfg = cls(enabled=False,
                      version=str(d.get("memory_version", "V1")).upper())
            cfg.validate()
            return cfg

        kwargs: Dict[str, Any] = {"enabled": True}
        known = {f.name: f for f in fields(cls)}
        unknown, retired = [], []
        for key, value in d.items():
            if not key.startswith(PREFIX) or value is None:
                continue
            if key in RETIRED:
                retired.append(key)
                continue
            name = key[len(PREFIX):]
            if name not in known or name == "enabled":
                unknown.append(key)
                continue
            # `from __future__ import annotations` makes field.type a string,
            # so both forms are checked.
            target = known[name].type
            try:
                if target is bool or target == "bool":
                    value = _as_bool(value)
                elif target is int or target == "int":
                    value = int(value)
                elif target is float or target == "float":
                    value = float(value)
                else:
                    value = str(value)
            except (TypeError, ValueError):
                raise ValueError(f"[memory] bad value for {key}: {value!r}")
            kwargs[name] = value

        if verbose and retired:
            print(f"[memory] these keys no longer exist (the module does not "
                  f"embed anything now): {', '.join(sorted(retired))}")
        if verbose and unknown:
            print(f"[memory] unknown memory_* key(s) ignored: "
                  f"{', '.join(sorted(unknown))}")

        cfg = cls(**kwargs)
        cfg.version = str(cfg.version).strip().upper()
        cfg.validate(group_size=d.get("group_size"))
        return cfg

    @property
    def is_v2(self) -> bool:
        return self.version == "V2"

    def resolve_comparison_n(self, group_size: int) -> int:
        """Resolve and validate V2's fixed best-of-n comparison budget."""
        if not self.is_v2 or not self.outcome_credit:
            return int(self.arm_comparison_n)
        k = int(group_size)
        if k < 3:
            raise ValueError(
                "memory V2 causal arms require group_size >= 3")
        n = int(self.arm_comparison_n)
        if n <= 0:
            selected_fraction = 1.0 - (
                self.arm_control_fraction + self.arm_explore_fraction)
            smallest = min(selected_fraction, self.arm_control_fraction,
                           self.arm_explore_fraction)
            n = max(1, int(math.floor(k * smallest + 0.5)))
            n = min(n, k // 3)
            self.arm_comparison_n = n
        if n < 1 or 3 * n > k:
            raise ValueError(
                "memory_arm_comparison_n must be >= 1 and leave room for "
                "selected, no-memory, and exploration arms "
                f"(3*n <= group_size; got n={n}, group_size={k})")
        return n

    def validate(self, group_size=None) -> None:
        self.version = str(self.version).strip().upper()
        if self.version not in ("V1", "V2"):
            raise ValueError("memory_version must be V1 or V2")
        if self.lessons_per_call < 1:
            raise ValueError("memory_lessons_per_call must be >= 1")
        if self.hygiene_profile not in ("auto", "geometry", "kernel", "generic"):
            raise ValueError(
                "memory_hygiene_profile must be auto|geometry|kernel|generic")
        if self.extract_mode not in ("contrast", "split"):
            raise ValueError("memory_extract_mode must be contrast|split")
        if self.extract_from not in ("both", "failure", "success"):
            raise ValueError("memory_extract_from must be both|failure|success")
        if self.lookup_mode not in ("select", "all", "none"):
            raise ValueError("memory_lookup_mode must be select|all|none")
        if self.lookup_fallback not in ("none", "recent", "importance"):
            raise ValueError("memory_lookup_fallback must be none|recent|importance")
        if self.inject_mode not in ("append", "system"):
            raise ValueError("memory_inject_mode must be append|system")
        if self.lookup_max_select < 0:
            raise ValueError("memory_lookup_max_select must be >= 0")
        if not 0.0 <= self.arm_control_fraction <= 1.0:
            raise ValueError("memory_arm_control_fraction must be in [0, 1]")
        if not 0.0 <= self.arm_explore_fraction <= 1.0:
            raise ValueError("memory_arm_explore_fraction must be in [0, 1]")
        if self.arm_control_fraction + self.arm_explore_fraction > 1.0:
            raise ValueError("memory arm fractions must sum to <= 1")
        if self.arm_max_lessons < 1:
            raise ValueError("memory_arm_max_lessons must be >= 1")
        if self.arm_exploration_c < 0:
            raise ValueError("memory_arm_exploration_c must be >= 0")
        if self.arm_comparison_n < 0:
            raise ValueError("memory_arm_comparison_n must be >= 0")
        if self.outcome_credit and self.arm_control_fraction <= 0:
            raise ValueError(
                "memory_outcome_credit requires memory_arm_control_fraction > 0")
        if self.outcome_credit and self.arm_max_lessons != 1:
            raise ValueError(
                "memory_outcome_credit requires memory_arm_max_lessons == 1 "
                "for identifiable lesson credit")
        if self.outcome_credit and (
                self.lookup_mode != "select" or self.lookup_max_select != 1):
            raise ValueError(
                "memory_outcome_credit requires memory_lookup_mode=select and "
                "memory_lookup_max_select=1")
        if self.enabled and self.is_v2:
            if not self.outcome_credit:
                raise ValueError(
                    "memory V2 requires memory_outcome_credit=true")
            if self.arm_explore_fraction <= 0:
                raise ValueError(
                    "memory V2 requires memory_arm_explore_fraction > 0")
            if self.arm_control_fraction + self.arm_explore_fraction >= 1.0:
                raise ValueError(
                    "memory V2 requires a positive selected-memory fraction")
            if self.text_reinforce:
                raise ValueError(
                    "memory V2 requires memory_text_reinforce=false; textual "
                    "repetition is not causal evidence")
            if group_size is not None:
                self.resolve_comparison_n(int(group_size))

    def describe(self) -> str:
        if not self.enabled:
            return "memory OFF"
        src = ("" if self.extract_from == "both"
               else f"-{self.extract_from}-only")
        cur = "" if self.curate_every <= 0 else f"  curate/{self.curate_every}"
        arms = ""
        if self.arm_control_fraction > 0 or self.arm_explore_fraction > 0:
            arms = (f"  arms=null:{self.arm_control_fraction:.0%}/"
                    f"explore:{self.arm_explore_fraction:.0%}")
        comparison = (f"  best@n={self.arm_comparison_n}"
                      if self.is_v2 and self.outcome_credit else "")
        label = "memory V2 ON" if self.is_v2 else "memory ON"
        return (f"{label}  extract={self.extract_mode}{src}{cur}  "
                f"lookup={self.lookup_mode}"
                f"(<={self.lookup_max_select})  L<={self.lessons_per_call}  "
                f"cap={self.max_lessons}  budget={self.token_budget}tok  "
                f"constructions={'forbidden' if self.forbid_constructions else 'allowed'}  "
                f"inject={self.inject_mode}{arms}{comparison}")


def _as_bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    return str(v).strip().lower() in ("1", "true", "yes", "y", "on")
